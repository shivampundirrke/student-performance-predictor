// ===== Multiple Linear Regression from scratch (no libraries) =====
let beta = [0,0,0,0];

function shuffle(a){ a=a.slice(); for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];} return a; }

// Solve A x = b using Gaussian elimination
function solve(A,b){
  const n=b.length, M=A.map((r,i)=>[...r,b[i]]);
  for(let i=0;i<n;i++){
    let p=i; for(let r=i+1;r<n;r++) if(Math.abs(M[r][i])>Math.abs(M[p][i])) p=r;
    [M[i],M[p]]=[M[p],M[i]];
    for(let r=i+1;r<n;r++){const f=M[r][i]/M[i][i]; for(let c=i;c<=n;c++) M[r][c]-=f*M[i][c];}
  }
  const x=Array(n).fill(0);
  for(let i=n-1;i>=0;i--){let s=M[i][n]; for(let c=i+1;c<n;c++) s-=M[i][c]*x[c]; x[i]=s/M[i][i];}
  return x;
}

// Normal equation: beta = (X^T X)^-1 X^T y
function fit(rows){
  const X=rows.map(r=>[1,r[0],r[1],r[2]]), y=rows.map(r=>r[3]), k=4;
  const XtX=Array.from({length:k},(_,i)=>Array.from({length:k},(_,j)=>X.reduce((s,r)=>s+r[i]*r[j],0)));
  const Xty=Array.from({length:k},(_,i)=>X.reduce((s,r,n)=>s+r[i]*y[n],0));
  return solve(XtX,Xty);
}

const predict=(h,a,p)=>Math.max(0,Math.min(100,beta[0]+beta[1]*h+beta[2]*a+beta[3]*p));

function evaluate(rows){
  const y=rows.map(r=>r[3]), pr=rows.map(r=>predict(r[0],r[1],r[2]));
  const mean=y.reduce((s,v)=>s+v,0)/y.length;
  const ssRes=y.reduce((s,v,i)=>s+(v-pr[i])**2,0), ssTot=y.reduce((s,v)=>s+(v-mean)**2,0);
  const mae=y.reduce((s,v,i)=>s+Math.abs(v-pr[i]),0)/y.length;
  return {r2:1-ssRes/ssTot, mae, y, pr};
}

function drawChart(y,pr){
  const c=document.getElementById('chart'), g=c.getContext('2d'), W=c.width, H=c.height, m=44;
  g.clearRect(0,0,W,H); g.font='12px system-ui'; g.fillStyle='#1d2740'; g.strokeStyle='#d5dcea';
  const sx=v=>m+(v/100)*(W-m-16), sy=v=>H-m-(v/100)*(H-m-16);
  for(let t=0;t<=100;t+=20){
    g.beginPath(); g.moveTo(sx(t),sy(0)); g.lineTo(sx(t),sy(100)); g.moveTo(sx(0),sy(t)); g.lineTo(sx(100),sy(t)); g.stroke();
    g.fillText(t,sx(t)-8,H-m+16); g.fillText(t,m-26,sy(t)+4);
  }
  g.fillText('Actual marks',W/2-30,H-8); g.save(); g.translate(12,H/2+30); g.rotate(-Math.PI/2); g.fillText('Predicted marks',0,0); g.restore();
  g.strokeStyle='#b4570a'; g.setLineDash([6,4]); g.beginPath(); g.moveTo(sx(0),sy(0)); g.lineTo(sx(100),sy(100)); g.stroke(); g.setLineDash([]);
  g.fillStyle='#0b7d80'; y.forEach((v,i)=>{g.beginPath(); g.arc(sx(v),sy(pr[i]),5,0,7); g.fill();});
}

function train(){
  const d=shuffle(DATA), cut=Math.floor(d.length*0.8), tr=d.slice(0,cut), te=d.slice(cut);
  beta=fit(tr);
  const e=evaluate(te), f=v=>(v<0?'- ':'+ ')+Math.abs(v).toFixed(2);
  document.getElementById('eq').textContent=
    `marks = ${beta[0].toFixed(2)} ${f(beta[1])}×hours ${f(beta[2])}×attendance ${f(beta[3])}×previous`;
  document.getElementById('mR2').textContent=e.r2.toFixed(3);
  document.getElementById('mMAE').textContent=e.mae.toFixed(2);
  document.getElementById('mN').textContent=`${tr.length} / ${te.length}`;
  drawChart(e.y,e.pr);
}

function gradeOf(m){
  if(m>=85) return 'Grade A — Excellent, aise hi chalte raho!';
  if(m>=70) return 'Grade B — Good, thodi aur mehnat se A possible hai.';
  if(m>=55) return 'Grade C — Average, study hours aur attendance badhao.';
  if(m>=40) return 'Grade D — Pass, lekin risk zone me ho.';
  return 'Fail risk — turant study plan banao aur class attend karo.';
}

function show(){
  const h=+hours.value, a=+att.value, p=+prev.value, m=predict(h,a,p);
  marks.textContent=m.toFixed(1); grade.textContent=gradeOf(m);
  const parts=[['Study hours',beta[1]*h],['Attendance',beta[2]*a],['Previous marks',beta[3]*p]];
  const mx=Math.max(...parts.map(x=>Math.abs(x[1])));
  why.innerHTML='<b>Kisne kitna contribute kiya:</b>'+parts.map(([n,v])=>
    `<div class="bar"><span style="width:105px">${n}</span><i class="${v<0?'neg':''}" style="width:${Math.abs(v)/mx*120}px"></i>${v.toFixed(1)}</div>`).join('');
}

[['hours','oH'],['att','oA'],['prev','oP']].forEach(([i,o])=>{
  const el=document.getElementById(i); el.addEventListener('input',()=>document.getElementById(o).textContent=el.value);
});
go.addEventListener('click',show);
retrain.addEventListener('click',()=>{train(); if(marks.textContent!=='--') show();});
train();
