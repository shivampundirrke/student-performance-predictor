# Student Performance Prediction (B.Tech AI/ML - Year 1)

Inputs: study hours, attendance %, previous marks  ->  Output: predicted final marks + grade.

## Run kaise kare
1. Zip extract karo.
2. `index.html` ko browser me double-click karke open karo (internet ki zaroorat nahi).
3. Optional Python version: `cd python && pip install pandas scikit-learn matplotlib && python train_model.py`

## Files
- index.html, style.css, script.js - web app + model (JS me from scratch)
- data.js - dataset (60 students, synthetic)
- python/students.csv, python/train_model.py - scikit-learn version

## Viva me ye bolna
- Algorithm: Multiple Linear Regression (supervised learning, regression problem)
- Formula: y = b0 + b1*x1 + b2*x2 + b3*x3, coefficients Normal Equation se
- Metrics: R2 (kitna variance explain hua), MAE (average error in marks)
- Limitation: data synthetic hai; real data aur features (sleep, assignments) se accuracy badh sakti hai
- Future scope: Logistic Regression for Pass/Fail, Random Forest, Flask/Streamlit deployment
