"""Student Performance Prediction - Python (scikit-learn) version.
Run:  pip install pandas scikit-learn matplotlib
      python train_model.py
"""
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_absolute_error

df = pd.read_csv("students.csv")
X = df[["study_hours", "attendance", "previous_marks"]]
y = df["final_marks"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model = LinearRegression().fit(X_train, y_train)
pred = model.predict(X_test)

print("Intercept :", round(model.intercept_, 2))
for name, c in zip(X.columns, model.coef_):
    print(f"{name:15s}: {c:.3f}")
print("R2 score  :", round(r2_score(y_test, pred), 3))
print("MAE       :", round(mean_absolute_error(y_test, pred), 2))

# Predict for a new student
new = pd.DataFrame([[6, 85, 70]], columns=X.columns)
print("Predicted final marks for (6 hrs, 85%, 70 prev):", round(model.predict(new)[0], 1))

plt.scatter(y_test, pred, color="teal")
plt.plot([0, 100], [0, 100], "--", color="orange")
plt.xlabel("Actual marks"); plt.ylabel("Predicted marks"); plt.title("Actual vs Predicted")
plt.show()
